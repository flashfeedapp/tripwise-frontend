import { isPlatformBrowser } from '@angular/common';
import { Component, Input, OnChanges, OnDestroy, PLATFORM_ID, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import {
  Destination,
  DestinationAttraction,
  DestinationCategory,
  DestinationContentJson,
  DestinationExperience,
  DestinationFaq,
  DestinationFood,
  DestinationImage,
} from '../../models/trip.models';
import {
  destinationAttractionImages,
  destinationHeroImages,
  destinationTextItems,
  hideBrokenDestinationImage,
} from '../../shared/destination-image-content';
import { DestinationBackdropComponent } from '../destination-backdrop/destination-backdrop.component';

@Component({
  selector: 'app-destination-guide',
  standalone: true,
  imports: [DestinationBackdropComponent, RouterLink],
  templateUrl: './destination-guide.component.html',
})
export class DestinationGuideComponent implements OnChanges, OnDestroy {
  @Input({ required: true }) destination!: Destination;
  @Input() showPlanCta = false;
  @Input() immersive = false;

  protected slideIndex = 0;
  private readonly isBrowser = isPlatformBrowser(inject(PLATFORM_ID));
  private slideTimer: ReturnType<typeof setInterval> | null = null;

  protected get heroPhotos(): DestinationImage[] {
    return this.destination ? destinationHeroImages(this.destination) : [];
  }

  protected get attractionPhotos(): DestinationImage[] {
    return this.destination ? destinationAttractionImages(this.destination) : [];
  }

  protected get highlights(): string[] {
    return this.destination ? destinationTextItems(this.destination.highlights) : [];
  }

  protected get historyText(): string | null {
    return (
      this.content?.historyAndCulture?.history?.trim() ||
      this.destination?.history?.trim() ||
      null
    );
  }

  protected get cultureText(): string | null {
    return this.content?.historyAndCulture?.culture?.trim() || null;
  }

  protected get whyVisit(): string[] {
    return this.contentItems(this.destination?.contentJson?.whyVisit ?? this.highlights);
  }

  protected get content(): DestinationContentJson | null {
    return this.destination?.contentJson ?? null;
  }

  protected get experiences(): DestinationExperience[] {
    return this.content?.experiences ?? [];
  }

  protected get localFood(): DestinationFood[] {
    const food = this.content?.localFood;
    if (!food) {
      return [];
    }

    return (Array.isArray(food) ? food : [food])
      .map((item) => (typeof item === 'string' ? { name: item } : item))
      .filter((item) => item.name.trim().length > 0);
  }

  protected get faqs(): DestinationFaq[] {
    return this.content?.faqs ?? [];
  }

  protected get bestTimeMonths(): string | null {
    const bestTime = this.content?.bestTimeToVisit;
    if (typeof bestTime === 'string') {
      return bestTime.trim() || null;
    }
    return bestTime?.months?.trim() || this.destination?.bestSeason?.trim() || null;
  }

  protected get bestTimeWeather(): string | null {
    const bestTime = this.content?.bestTimeToVisit;
    return typeof bestTime === 'object' && bestTime
      ? bestTime.weather?.trim() || null
      : null;
  }

  protected get howToReach(): string[] {
    const reach = this.content?.howToReach ?? this.destination?.howToReach;
    if (typeof reach === 'string') {
      return this.contentItems(reach);
    }
    if (Array.isArray(reach)) {
      return this.contentItems(reach);
    }
    return reach && typeof reach === 'object'
      ? Object.entries(reach)
          .filter((entry): entry is [string, string] => typeof entry[1] === 'string')
          .map(([mode, details]) => `${this.formatLabel(mode)}: ${details}`)
      : [];
  }

  protected get localTransport(): string[] {
    return this.contentItems(
      this.content?.localTransport ?? this.destination?.localTransport,
    );
  }

  ngOnChanges(): void {
    this.slideIndex = 0;
    this.stopSlideshow();
    if (this.isBrowser && this.heroPhotos.length > 1) {
      this.slideTimer = setInterval(() => this.nextSlide(), 5000);
    }
  }

  ngOnDestroy(): void {
    this.stopSlideshow();
  }

  protected nextSlide(): void {
    if (this.heroPhotos.length > 1) {
      this.slideIndex = (this.slideIndex + 1) % this.heroPhotos.length;
    }
  }

  protected previousSlide(): void {
    if (this.heroPhotos.length > 1) {
      this.slideIndex = (this.slideIndex - 1 + this.heroPhotos.length) % this.heroPhotos.length;
    }
  }

  protected selectSlide(index: number): void {
    if (index >= 0 && index < this.heroPhotos.length) {
      this.slideIndex = index;
    }
  }

  protected formatCategory(category: DestinationCategory): string {
    return category
      .replaceAll('_AND_', ' & ')
      .replaceAll('_', ' ')
      .split(' ')
      .map((word) => word.charAt(0) + word.slice(1).toLowerCase())
      .join(' ');
  }

  protected textList(value: unknown): string[] {
    return this.contentItems(value);
  }

  protected contentItems(value: unknown): string[] {
    if (Array.isArray(value)) {
      return value
        .flatMap((item) => this.contentItems(item))
        .filter(Boolean);
    }

    if (typeof value === 'string') {
      return destinationTextItems(value);
    }

    return value !== null && typeof value === 'object'
      ? Object.values(value).flatMap((item) => this.contentItems(item))
      : [];
  }

  protected attractionDescription(attractionTitle: string): string | null {
    return this.attractionDetails(attractionTitle)?.description?.trim() || null;
  }

  protected attractionWhyVisit(attractionTitle: string): string | null {
    return this.attractionDetails(attractionTitle)?.whyVisit?.trim() || null;
  }

  protected experienceImageUrl(experience: DestinationExperience): string | null {
    const providedUrl = experience.imageUrl?.trim();
    if (providedUrl) {
      return providedUrl;
    }

    const experienceTerms = new Set(
      experience.title
        .toLocaleLowerCase()
        .split(/[^a-z0-9]+/)
        .filter((term) => term.length > 3),
    );
    if (experienceTerms.size === 0) {
      return null;
    }

    return (
      this.attractionPhotos.find((image) =>
        image.title
          .toLocaleLowerCase()
          .split(/[^a-z0-9]+/)
          .some((term) => term.length > 3 && experienceTerms.has(term)),
      )?.imageUrl ?? null
    );
  }

  protected onHeroImageError(event: Event): void {
    const image = event.currentTarget;
    if (!(image instanceof HTMLImageElement)) {
      return;
    }

    const wasActive = image.classList.contains('active');
    image.hidden = true;
    if (wasActive && this.heroPhotos.length > 1) {
      this.nextSlide();
    }
    if ([...image.parentElement?.querySelectorAll('img') ?? []].every((photo) => photo.hidden)) {
      image.parentElement?.classList.add('image-unavailable');
    }
  }

  protected onAttractionImageError(event: Event): void {
    hideBrokenDestinationImage(event);
  }

  protected onExperienceImageError(event: Event): void {
    hideBrokenDestinationImage(event);
  }

  private attractionDetails(title: string): DestinationAttraction | undefined {
    const normalize = (value: string): string => value.trim().toLocaleLowerCase();
    const normalizedTitle = normalize(title);
    return this.content?.attractions?.find(
      (attraction) => {
        const normalizedName = normalize(attraction.name);
        return (
          normalizedName === normalizedTitle ||
          normalizedName.includes(normalizedTitle) ||
          normalizedTitle.includes(normalizedName)
        );
      },
    );
  }

  private formatLabel(value: string): string {
    return value.charAt(0).toUpperCase() + value.slice(1).toLowerCase();
  }

  private stopSlideshow(): void {
    if (this.slideTimer !== null) {
      clearInterval(this.slideTimer);
      this.slideTimer = null;
    }
  }
}
